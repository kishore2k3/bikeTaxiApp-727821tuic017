package com.example.bikeTaxiApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeTaxiAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BikeTaxiAppApplication.class, args);
	}

}
